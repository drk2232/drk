# CAPL-scripts
A personal repository to store CAPL script (Vector canoe programming language) and documentation.
1. CAPL script to trigger an action (electrical actuator) in function of a measured CAN parameter (pressure value from an ECU)
